var towerimage,tower;
var doorimage,door,doorgroup;
var climberimage,climber,climbergroup;
var ghostimage,ghost;
var invisibleclimber,iclimber,iclimbergroup;
var gameState = "play";


function preload(){
  towerimage = loadImage("tower.png");
  doorimage = loadImage("door.png");
  climberimage = loadImage("climber.png")
  ghostimage = loadImage("ghost-standing.png")
  spookysound = loadSound("spooky.wav")
}
function setup(){
 createCanvas(600,600);
  tower = createSprite(300,50,50,55);
  tower.addImage(towerimage);
  tower.velocityY = 5
  
  ghost = createSprite(300,200,50,150);
  ghost.addImage(ghostimage);
  ghost.scale = 0.3;
  
  
  doorgroup = new Group()
  climbergroup = new Group()
  iclimbergroup = new Group()
 
  
}
function draw(){
  background("blue");
  spookysound.play()
  drawSprites()
  
  if (gameState === "play"){
    if (tower.y > 590){
    tower.y = 50
  }
  ghost.velocityY = 2;
  if (keyDown("space")){
    ghost.velocityY = -2;
  }
  
  if (keyDown("left")){
    ghost.x = ghost.x + -2;
  }
  
  if (keyDown("right")){
    ghost.x = ghost.x + 2;
  }
  
  
  spawndoors();
     if (ghost.isTouching(iclimbergroup)){
       gameState = "end"
     }
  }
  else if(gameState === "end"){
    background("black");
    stroke("yellow");
    fill("yellow");
    textSize(20);
    text("GAME OVER", 230,250);
    text("PRESS R TO RESET",230,300);
    spookysound.stop()
    if(keyDown("r")) {
      reset();
    }
  }
}
 

function spawndoors(){
  if(frameCount%60===0){
    door = createSprite(300,20,50,80)
    door.velocityY=5
    door.x=random(150,500);
    door.addImage(doorimage);
    door.lifetime=300;
    doorgroup.add(door)
        climber = createSprite(300,60,50,80)
    climber.velocityY=5
    climber.x=door.x;
    climber.addImage(climberimage);
    climber.lifetime=300;
    climbergroup.add(climber)
    iclimber = createSprite(300,60,100,20);
    iclimber.velocityY = 5;
    iclimber.x = climber.x;
    iclimber.lifetime = 300;
    iclimber.visible = false;
    iclimbergroup.add(iclimber)
  }}


function reset(){
  gameState= "play";
  doorgroup.destroyEach();
  climbergroup.destroyEach();
  iclimbergroup.destroyEach();
  }